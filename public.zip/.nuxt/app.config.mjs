
import { defuFn } from 'C:/Users/omkar/OneDrive/Documents/GitHub/Shadian/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default /* #__PURE__ */ defuFn(inlineConfig)
