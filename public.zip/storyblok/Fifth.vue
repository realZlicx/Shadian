<template>
    <div class="w-full px-10 xl:px-14 grid grid-cols-3 gap-x-10 py-28">
        <div class="w-full space-y-10">
            <h2 class="font-bold text-5xl">Some pieces of our <br class="hidden 2xl:block"> work</h2>
            <p class="2xl:pr-[4%] text-lg text-[#919090]">Risus commodo id odio turpis pharetra elementum. Pulvinar porta
                porta feugiat
                scelerisque in elit. Morbi
                rhoncus, tellus, eros consequat magna semper orci a tincidunt. </p>

            <div class="text-[#ffa800] border-2 font-bold w-fit border-[#ffa800] py-3 px-6 rounded-3xl">
                SHOW MORE
            </div>
        </div>

        <div class="w-full space-y-10">
            <div class="p-6 border border-white  rounded-md space-y-5">
                <div class="py-20 bg-[#8474C4] rounded-md"></div>
                <div class="bg-[#ffa800] text-black uppercase font-medium rounded-md py-1.5 px-3 text-sm w-fit">Website
                </div>
                <div class="text-2xl font-semibold">Creative landing page</div>
                <div class="flex gap-x-2 items-center">
                    <span class="text-[#919090]">Read More</span>
                    <img src="@/assets/icons/arrow-circle-right.svg" class="h-5 w-5" alt="">
                </div>
            </div>


            <div class="p-6 border border-white  rounded-md space-y-5">
                <div class="bg-[#ffa800] text-black uppercase font-medium rounded-md py-1.5 px-3 text-sm w-fit">Website
                </div>
                <div class="text-2xl font-semibold">Creative Branding</div>
                <div class="flex gap-x-2 items-center">
                    <span class="text-[#919090]">Read More</span>
                    <img src="@/assets/icons/arrow-circle-right.svg" class="h-5 w-5" alt="">
                </div>
            </div>


            <div class="p-6 border border-white  rounded-md space-y-5">
                <div class="bg-[#ffa800] text-black uppercase font-medium rounded-md py-1.5 px-3 text-sm w-fit">Website
                </div>
                <div class="text-2xl font-semibold">Why We Collect User’s Data</div>
                <div class="flex gap-x-2 items-center">
                    <span class="text-[#919090]">Read More</span>
                    <img src="@/assets/icons/arrow-circle-right.svg" class="h-5 w-5" alt="">
                </div>
            </div>
        </div>
        <div class="w-full space-y-10">
            <div class="p-6 border border-white  rounded-md space-y-5">
                <div class="bg-[#ffa800] text-black uppercase font-medium rounded-md py-1.5 px-3 text-sm w-fit">Website
                </div>
                <div class="text-2xl font-semibold">Creative landing page</div>
                <div class="flex gap-x-2 items-center">
                    <span class="text-[#919090]">Read More</span>
                    <img src="@/assets/icons/arrow-circle-right.svg" class="h-5 w-5" alt="">
                </div>
            </div>

            <div class="p-6 border border-white  rounded-md space-y-5">
                <div class="py-20 bg-[#8474C4] rounded-md"></div>
                <div class="bg-[#ffa800] text-black uppercase font-medium rounded-md py-1.5 px-3 text-sm w-fit">Website
                </div>
                <div class="text-2xl font-semibold">How We Optimized Our SEO</div>
                <div class="flex gap-x-2 items-center">
                    <span class="text-[#919090]">Read More</span>
                    <img src="@/assets/icons/arrow-circle-right.svg" class="h-5 w-5" alt="">
                </div>
            </div>

            <div class="p-6 border border-white  rounded-md space-y-5">
                <div class="bg-[#ffa800] text-black uppercase font-medium rounded-md py-1.5 px-3 text-sm w-fit">Website
                </div>
                <div class="text-2xl font-semibold">Automation. Advanced Level</div>
                <div class="flex gap-x-2 items-center">
                    <span class="text-[#919090]">Read More</span>
                    <img src="@/assets/icons/arrow-circle-right.svg" class="h-5 w-5" alt="">
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>

</script>
