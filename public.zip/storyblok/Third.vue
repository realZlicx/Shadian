<template>
    <div class="w-full flex flex-col items-center py-28 justify-center bg-[#110f0f] gap-y-10">
        <div class="text-center space-y-10">

            <div class="text-white text-5xl font-bold">We Offer</div>
            <div class="text-[#919090]">Risus commodo id odio turpis pharetra elementum. Pulvinar porta porta feugiat<br>
                scelerisque in elit. Morbi rhoncus, tellus, eros consequat magna semper orci a <br> tincidunt. </div>
        </div>
        <div class="flex gap-x-20">
            <div class="h-52 w-96 border-2 border-[#a1aebf] pl-6 pt-5 rounded-md gap-y-5 flex flex-col">
                <img class="h-9 w-9" src="@/assets/branding.svg" alt="">
                <p class="font-semibold text-2xl">Branding</p>
                <p class="text-xs text-[#a09f9f]">Egestas tellus nunc proin amet tellus tincidunt lacus consequat. Ultrices</p>
            </div>

            <div class="h-52 w-96 border-2 border-[#a1aebf] pl-6 pt-5 rounded-md gap-y-5 flex flex-col">
                <img class="h-9 w-9" src="@/assets/webdevelopment.svg" alt="">
                <p class="font-semibold text-2xl">Web development</p>
                <p class="text-xs text-[#a09f9f]">Integer ante non nunc, eget est justo vel semper nunc. Lacus </p>
            </div>

            <div class="h-52 w-96 border-2 border-[#a1aebf] pl-6 pt-5 rounded-md gap-y-5 flex flex-col">
                <img class="h-9 w-9" src="@/assets/digitalmarketing.svg" alt="">
                <p class="font-semibold text-2xl">Digital Marketing</p>
                <p class="text-xs text-[#a09f9f]">Sed faucibus faucibus egestas volutpat, accumsan adipiscing egestas est. Auctor et <br>leo urna est.</p>
            </div>
        </div>
        <div class="flex gap-x-20">
            <div class="h-52 w-96 border-2 border-[#a1aebf] pl-6 pt-5 rounded-md gap-y-5 flex flex-col">
                <img class="h-9 w-9" src="@/assets/mobileapp.svg" alt="">
                <p class="font-semibold text-2xl">Mobile App</p>
                <p class="text-xs text-[#a09f9f]">Egestas tellus nunc proin amet tellus tincidunt lacus consequat. Ultrices</p>
            </div>

            <div class="h-52 w-96 border-2 border-[#a1aebf] pl-6 pt-5 rounded-md gap-y-5 flex flex-col">
                <img class="h-9 w-9" src="@/assets/seo.svg" alt="">
                <p class="font-semibold text-2xl">SEO</p>
                <p class="text-xs text-[#a09f9f]">Integer ante non nunc, eget est justo vel semper nunc. Lacus </p>
            </div>

            <div class="h-52 w-96 border-2 border-[#a1aebf] pl-6 pt-5 rounded-md gap-y-5 flex flex-col">
                <img class="h-9 w-9" src="@/assets/usertesting.svg" alt="">
                <p class="font-semibold text-2xl">User Testing</p>
                <p class="text-xs text-[#a09f9f]">Sed faucibus faucibus egestas volutpat, accumsan adipiscing egestas est. Auctor et <br>leo urna est.</p>
            </div>
        </div>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped></style>