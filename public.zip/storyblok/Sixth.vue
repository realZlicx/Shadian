<template>
    <div class="px-10 xl:px-14 py-32 bg-black space-y-20">
        <div class="text-white w-full flex items-end justify-between">
            <h3>Hear what our customers say {{ `:)` }}</h3>

            <div class="flex gap-x-6">
                <img src="@/assets/icons/box-arrow-left.svg" class="h-14" alt="">
                <img src="@/assets/icons/box-arrow-right.svg" class="h-14" alt="">
            </div>
        </div>

        <div class="w-full flex justify-between">
            <div class="flex gap-x-10">
                <div
                    class="h-68 w-96 border-2 border-[#a1aebf] pl-6 pt-5 rounded-md gap-y-5 flex flex-col bg-[#0f0f0f]">
                    <div class="flex">
                        <img class="" src="@/assets/user1.svg" alt="">
                        <div class=" flex flex-col ml-3 justify-center">
                            <p class="font-light text-base">Brooklyn Simmons</p>
                            <p class="text-[#a09f9f] text-sm font-light">manam</p>
                        </div>
                    </div>
                    <p class="text-sm text-white font-bold">Sit ut diam bibendum dolor.<br> Ullamcorper pharetra nibh eget<br> vitae
                        pulvinar. Placerat sapien,<br> dolor, aenean vivamus in tincidunt<br> et. Mauris dolor vestibulum et<br> lacus a
                        ante orci.</p>
                </div>

            </div>

            <div class="flex gap-x-10">
                <div
                    class="h-52 w-96 border-2 border-[#a1aebf] pl-6 pt-5 rounded-md gap-y-5 flex flex-col bg-[#0f0f0f]">
                    <div class="flex">
                        <img class="" src="@/assets/user2.svg" alt="">
                        <div class=" flex flex-col ml-3 justify-center">
                            <p class="font-light text-base">Esther Howard</p>
                            <p class="text-[#a09f9f] text-sm font-light">Offmax</p>
                        </div>
                    </div>
                    <p class="text-sm text-white font-bold">Vitae tellus bibendum nibh integer<br>auctor pretium sed. Sollicitudin<br> tristique euismod elit.</p>
                </div>

            </div>

            <div class="flex gap-x-10">
                <div
                    class="h-64 w-96 border-2 border-[#a1aebf] pl-6 pt-5 rounded-md gap-y-5 flex flex-col bg-[#0f0f0f]">
                    <div class="flex">
                        <img class="" src="@/assets/user3.svg" alt="">
                        <div class=" flex flex-col ml-3 justify-center">
                            <p class="font-light text-base">Arlene McCoy</p>
                            <p class="text-[#a09f9f] text-sm font-light">bloopixel</p>
                        </div>
                    </div>
                    <p class="text-sm text-white font-bold">Eu eu eget lorem commodo<br>sagittis enim in viverra. Urna<br>egestas ipsum gravida tempor.<br>Libero, consectetur urna in enim<br> magnis. Est..</p>
                </div>

            </div>

            <div class="flex gap-x-10">
                <div
                    class="h-72 w-96 border-2 border-[#a1aebf] pl-6 pt-5 rounded-md gap-y-5 flex flex-col bg-[#0f0f0f]">
                    <div class="flex">
                        <img class="" src="@/assets/user4.svg" alt="">
                        <div class=" flex flex-col ml-3 justify-center">
                            <p class="font-light text-base">Jane Cooper</p>
                            <p class="text-[#a09f9f] text-sm font-light">unpexel</p>
                        </div>
                    </div>
                    <p class="text-sm text-white font-bold">Amet aliquam, volutpat nisl, duis<br> sed at. Vehicula proin consectetur<br>risus dictumst nec amet<br>consequat at tempus. Ornare<br>dapibus nunc fames nibh morbi<br>viverra eu sed mattis.</p>
                </div>

            </div>
        </div>
    </div>
</template>

<script setup>

</script>
