<template>
    <div class="w-full bg-black px-10 xl:px-14 py-20">
        <div class="grid px-20 grid-cols-6">
            <div class="text-[#999999] space-y-4">
                <p class="text-white font-semibold">Company</p>
                <p>About us</p>
                <p>Team</p>
                <p>Careers</p>
            </div>

            <div class="text-[#999999] space-y-4">
                <p class="text-white font-semibold">Services</p>
                <p>Branding</p>
                <p>Web Development</p>
                <p>Digital Marketing</p>
                <p>Mobile app</p>
                <p>SEO</p>
                <p>User testing</p>
            </div>

            <div class="text-[#999999] space-y-4">
                <p class="text-white font-semibold">Resources</p>
                <p>Blog</p>
                <p>Case study</p>
                <p>Testimonials</p>
            </div>
            <div class="text-[#999999] space-y-4">
                <p class="text-white font-semibold">Follow us</p>
                <p>Instagram</p>
                <p>Figma</p>
            </div>

            <div class="text-[#999999] space-y-6 col-span-2">
                <div class="flex gap-x-8 items-center">
                    <img src="@/assets/logo.svg" class="h-12 " alt="">
                    <span class="text-white font-bold"> Shadient.co</span>
                </div>
                <p class="font-thin">Get Latest Updates</p>
                <input type="text" placeholder="Your email" class="border-white border bg-transparent rounded-full pl-3 w-1/2 pr-8 py-2">
            </div>
        </div>

    </div>
</template>

<script setup>

</script>
