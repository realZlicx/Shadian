<template>
    <div class="px-10 xl:px-14 py-24 bg-black">
        <div class="px-20 py-16 bg-[#100f0f]">
            <div class="bg-[#FFB219] py-20 gap-y-5 rounded-md flex flex-col items-center text-black">
                <h2 class="font-semibold text-4xl">Let’s discuss the idea</h2>
                <p class="max-w-xl text-center">Risus commodo id odio turpis pharetra elementum. Pulvinar porta porta
                    feugiat
                    scelerisque in elit. </p>

                <div class="flex items-center gap-x-3 mt-5">
                    <input type="text" placeholder="Email"
                        class="py-3 text-sm border-neutral-400 rounded-full w-72 px-4 border-2 bg-white placeholder:text-black">
                    <button class="bg-black text-xs px-8 py-3.5 rounded-full uppercase text-white">Send</button>
                </div>
            </div>
        </div>

    </div>
</template>

<script setup>

</script>
