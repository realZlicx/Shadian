<template>
    <div class="w-full px-20 grid grid-cols-2 py-36 bg-black">
        <div class="h-full w-full flex items-center justify-center p-[20%]">
            <img src="@/assets/human.svg" class="h-full w-full" alt="">
        </div>

        <div class="h-full w-full pl-[10%] flex flex-col justify-center space-y-10">
            <h2 class="font-bold text-5xl">Why choose us</h2>
            <p class="text-[#919090] text-lg 2xl:pr-[18%]">Commodo diam vulputate dui proin quis enim nibh. Non integer ac libero
                facilisis
                hendrerit a at. Nisi
                sem ut
                sed sed faucibus at eu elit. Morbi aliquam porttitor mattis consequat neque, tellus blandit. </p>

            <div class="text-[#ffa800] border-2 font-bold w-fit border-[#ffa800] py-3 px-6 rounded-3xl">
                LET'S CONNECT
            </div>
        </div>
    </div>
</template>

<script setup>

</script>
