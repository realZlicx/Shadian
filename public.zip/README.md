# Nuxt3-Boilerplate
 Boilerplate for all the projects using nuxt 3
